package ir.mashak.mylogin

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

@Composable
fun SetupNavGraph(
    navController: NavHostController
) {
    NavHost(
        navController = navController,
        startDestination = Screen.LoginPage.route
    ) {
        composable(route = Screen.LoginPage.route) {
            LoginPage() { name, nationalCode ->
                navController.navigate(
                    Screen.ProfileDetails.route
                        .replace("{userName}", name)
                        .replace("{userNationalCode}", nationalCode)
                )
            }
        }

        composable(route = Screen.ProfileDetails.route) { backStackEntry ->
            ProfileDetails(
                backStackEntry.arguments?.getString("userName"),
                backStackEntry.arguments?.getString("userNationalCode")
            ){
                navController.popBackStack()
            }

        }
    }
}
