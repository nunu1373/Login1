package ir.mashak.mylogin

sealed class Screen( val route : String){
    object LoginPage : Screen(route = "Login_Screen")
    object ProfileDetails : Screen(route = "Profile_Screen/{userName}/{userNationalCode}")

}























