package ir.mashak.mylogin

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.magnifier
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.mashak.mylogin.ui.theme.darkText
import ir.mashak.mylogin.ui.theme.spacing


@Composable
fun ProfileDetails(
    name: String?,
    nationalCode: String?,
    onExitClicked: () -> Unit
) {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }

        item {
            Image(
                modifier = Modifier
                    .size(200.dp),
                painter = painterResource(id = R.drawable.welcome),
                contentDescription = "",
            )
        }
        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.extraSmall)) }

        item {
            Text(
                modifier = Modifier.padding(
                    horizontal = MaterialTheme.spacing.semiLarge
                ),
                style = MaterialTheme.typography.h6,
                text = stringResource(id = R.string.Welcome),
                color = MaterialTheme.colors.darkText,
                fontWeight = FontWeight.Bold
            )
        }
        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }

        item {

            Column(
                modifier = Modifier
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(Modifier.size(width = 300.dp, height = 72.dp).border(1.dp, Color.Black)) {
                    Row {
                        Text(text = name?:"",Modifier.weight(1f))
                        Spacer(
                            modifier = Modifier
                                .height(36.dp)
                                .width(2.dp)
                                .background(Color.Black)
                        )
                        Text(text = "           : نام و نام خانوادگی ",Modifier.weight(1f))
                    }
                    Spacer(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.Black)
                    )
                    Row {
                        Text(text = nationalCode?:"",Modifier.weight(1f))
                        Spacer(
                            modifier = Modifier
                                .height(36.dp)
                                .width(2.dp)
                                .background(Color.Black)
                        )
                        Text(text = "                 :  کد ملی",Modifier.weight(1f))
                    }

                }
            }
        }

        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }

        item {
            MyButton(text = stringResource(id = R.string.Exit)) {
                onExitClicked()
            }

        }
    }
}
