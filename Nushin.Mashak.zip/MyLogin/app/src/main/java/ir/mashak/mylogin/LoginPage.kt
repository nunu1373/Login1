 package ir.mashak.mylogin

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.mashak.mylogin.ui.theme.*


@Composable
fun LoginPage(onLoginCompleted:(String,String)->Unit) {

var fullName by remember { mutableStateOf("") }
    var nationalCode by remember { mutableStateOf("")  }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }
        item {
            Image(
                modifier = Modifier
                    .size(200.dp),
                painter = painterResource(id = R.drawable.user_fill),
                contentDescription = "",
            )
        }
        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }
        item {
            Text(
                modifier = Modifier.padding(
                    horizontal = MaterialTheme.spacing.semiLarge
                ),
                style = MaterialTheme.typography.h6,
                text = stringResource(id = R.string.loginTxt),
                color = MaterialTheme.colors.darkText,
                fontWeight = FontWeight.Bold
            )
        }
        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }
        item {
            Text(text = "نام و نام خانوادگی ")
            TextField(value = fullName,
                onValueChange = { fullName = it })
        }
        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }

        item {
            Text(text = "کد ملی ")
            TextField(value = nationalCode,
            onValueChange = { nationalCode = it })

        }
        item { Spacer(modifier = Modifier.height(MaterialTheme.spacing.large)) }
        item {
            MyButton(text = stringResource(id = R.string.register)) {

                onLoginCompleted(fullName,nationalCode)

            }
        }

    }

}



@Composable
fun MyButton(
    text: String,
    onClick: () -> Unit,
) {
    Button(
        onClick = { onClick() },
        colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colors.LightRed),
        modifier = Modifier
            .fillMaxWidth()
            .height(65.dp)
            .padding(
                start = MaterialTheme.spacing.semiLarge,
                end = MaterialTheme.spacing.semiLarge,
                bottom = MaterialTheme.spacing.medium
            ),
        shape = MaterialTheme.roundedShape.small
    ) {
        Text(
            text = text,
            color = Color.White,
            style = MaterialTheme.typography.h5
        )


    }
}



